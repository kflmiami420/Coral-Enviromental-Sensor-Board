Enviro+ pHAT
============

`Build Status <https://travis-ci.com/pimoroni/enviroplus-python>`__
`Coverage
Status <https://coveralls.io/github/pimoroni/enviroplus-python?branch=master>`__
`PyPi Package <https://pypi.python.org/pypi/enviroplus>`__ `Python
Versions <https://pypi.python.org/pypi/enviroplus>`__

Installing
==========

Stable library from PyPi:

-  Just run ``sudo pip install enviroplus``

(**Note** that you’re best using the git clone / install.sh method below
if you want all of the UART serial configuration for the PMS5003
particulate matter sensor to run automatically)

Latest/development library from GitHub:

-  ``git clone https://github.com/pimoroni/enviroplus-python``
-  ``cd enviroplus-python``
-  ``sudo ./install.sh``

0.0.1
-----

* Initial Release
